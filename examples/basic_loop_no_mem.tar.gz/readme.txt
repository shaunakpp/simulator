Performs multiplication by adding 2 16 times via a loop, and then stores the value in memory.

Does not include memory phase of the project.

