Loads a value (2), adds 123 to it, and writes it back to memory.


Does not include memory phase of the project.
